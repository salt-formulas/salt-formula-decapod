# -*- coding: utf-8 -*-
# Copyright (c) 2016 Mirantis Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""This module contains a model of the Token.

Token is an authorization abstraction. It presents a user session.
Every user may have several tokens. Each token has it's TTL
and expired tokens are invalid.
"""


import bson.objectid

from decapod_common import config
from decapod_common import timeutils
from decapod_common.models import generic
from decapod_common.models import properties


CONF = config.make_api_config()
"""Config."""


class TokenModel(generic.Model):
    """Model class for Token.

    Token is a session ID of the some user session. This is
    an identifier of some user session. It is also possible for
    user to have several tokens.
    """

    MODEL_NAME = "token"
    COLLECTION_NAME = "token"

    def __init__(self):
        super().__init__()

        self.user_id = None
        self.user = None
        self.expires_at = 0

    user = properties.ModelProperty(
        "decapod_common.models.user.UserModel",
        "user_id"
    )

    @classmethod
    def find_token(cls, token_id):
        """This method returns token by the given token_id.

        It also respects expiration time. So even if token is exist but
        expired, it won't be found.

        Returns None if nothing is found.
        """

        query = {
            "model_id": token_id,
            "expires_at": {"$gte": timeutils.datenow()}
        }

        document = cls.collection().find_one(query)
        if not document:
            return None

        model = cls()
        model.update_from_db_document(document)

        return model

    @classmethod
    def create(cls, user_id):
        """This method creates token for the user with given ID.

        Saves it into DB also.
        """

        model = cls()
        model.user = user_id
        model.initiator_id = user_id
        model.save()

        return model

    @classmethod
    def ensure_index(cls):
        collection = cls.collection()

        collection.create_index(
            [
                ("model_id", generic.SORT_ASC)
            ],
            unique=True,
            name="index_unique_token_id"
        )
        collection.create_index(
            "expires_at",
            expireAfterSeconds=0,
            name="index_token_ttl"
        )

    @property
    def default_ttl(self):
        """Returns a TTL for the token. It always returns seconds, integer."""

        return int(CONF["api"]["token"]["ttl_in_seconds"])

    def prolong(self, ttl=None):
        self.expires_at = timeutils.ttl(ttl or self.default_ttl)
        self.collection().update_one(
            {"_id": self._id},
            {"$set": {"expires_at": self.expires_at}}
        )

    def update_from_db_document(self, structure):
        super().update_from_db_document(structure)

        self.user_id = structure["user_id"]
        self.expires_at = structure["expires_at"]

    def make_db_document_specific_fields(self):
        expires_at = self.expires_at
        if not expires_at:
            expires_at = timeutils.ttl(self.default_ttl)

        return {
            "user_id": self.user_id,
            "expires_at": expires_at,
            "model_id": self.model_id,
            "initiator_id": self.initiator_id
        }

    def make_api_specific_fields(self, *args, **kwargs):
        return {
            "user": self.user,
            "expires_at": self.expires_at.timestamp()
        }


def revoke_tokens(*tokens):
    """This function takes a list of token IDs and revokes them from DB."""

    collection = TokenModel.collection()
    collection.delete_many(
        {
            "_id": {
                "$in": [bson.objectid.ObjectId(tok) for tok in tokens]
            }
        }
    )


def revoke_for_user(user_id):
    """This function revokes all user's tokens."""

    collection = TokenModel.collection()
    collection.delete_many({"user_id": user_id})
